package com.example.adaptive_inscribe

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
